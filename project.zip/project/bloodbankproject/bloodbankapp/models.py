from django.db import models


class admin(models.Model):
    emailid = models.CharField(primary_key=True, max_length=50)
    password = models.CharField(max_length=50, blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'admin'


class donor(models.Model):
    donorid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    gender = models.CharField(max_length=6, blank=True, null=True)
    birthdate = models.DateField(blank=True, null=True)
    address = models.CharField(max_length=50, blank=True, null=True)
    city = models.CharField(max_length=10, blank=True, null=True)
    phone = models.CharField(max_length=10, blank=True, null=True)
    email = models.CharField(unique=True, max_length=50, blank=True, null=True)
    password = models.CharField(max_length=50, blank=True, null=True)
    occupation = models.CharField(max_length=10, blank=True, null=True)
    bloodgroup = models.CharField(max_length=5, blank=True, null=True)
    maritalstatus = models.CharField(max_length=10, blank=True, null=True)
    lastdonationdate = models.DateField(blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'donor'


class blood(models.Model):
    bagid = models.AutoField(primary_key=True)
    bagsize = models.CharField(max_length=10, blank=True, null=True)
    donorid = models.ForeignKey('donor', models.DO_NOTHING, db_column='donorid', blank=True, null=True)
    bloodgroup=models.CharField(max_length=5, blank=True, null=True)
    collectdate = models.DateField(blank=True, null=True)
    expirydate = models.DateField(blank=True, null=True)
    usedate = models.DateField(blank=True, null=True)
    status = models.CharField(max_length=20, blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'blood'


class bloodstock(models.Model):
    bloodid = models.AutoField(primary_key=True)
    bloodgroup = models.CharField(max_length=5, blank=True, null=True)
    size = models.CharField(max_length=10, blank=True, null=True)
    stock=models.IntegerField(default=0)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'bloodstock'


class bloodtransaction(models.Model):
    transactionid = models.AutoField(primary_key=True)
    transactiondate = models.DateField(blank=True, null=True)
    bloodgroup = models.CharField(max_length=5, blank=True, null=True)
    inbag = models.IntegerField(blank=True, null=True)
    outbag = models.IntegerField(blank=True, null=True)
    stockbalance = models.IntegerField(blank=True, null=True)
    transtype = models.CharField(max_length=10, blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'bloodtransaction'


class bloodrequest(models.Model):
    requestid = models.AutoField(primary_key=True)
    requestdate = models.DateField(blank=True, null=True)
    bloodgroup = models.CharField(max_length=5, blank=True, null=True)
    name = models.CharField(max_length=10, blank=True, null=True)
    address = models.CharField(max_length=20, blank=True, null=True)
    city = models.CharField(max_length=10, blank=True, null=True)
    phoneno = models.CharField(max_length=10, blank=True, null=True)
    qty = models.CharField(max_length=11, blank=True, null=True)
    requeststatus = models.CharField(max_length=10, blank=True, null=True)
    bagsize = models.CharField(max_length=10, blank=True, null=True)
    pending=models.IntegerField(blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'bloodrequest'


class processrequest(models.Model):
    processid = models.AutoField(primary_key=True)
    requestid = models.ForeignKey('bloodrequest', models.DO_NOTHING, db_column='requestid', blank=True, null=True)
    processdate = models.DateField(blank=True, null=True)
    bagid = models.ForeignKey('blood', models.DO_NOTHING, db_column='bagid', blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'processrequest'


class bloodcamp(models.Model):
    campid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=10, blank=True, null=True)
    address = models.CharField(max_length=10, blank=True, null=True)
    city = models.CharField(max_length=10, blank=True, null=True)
    phoneno = models.CharField(max_length=10, blank=True, null=True)
    campdate = models.DateField(blank=True, null=True)
    Objects = models.Manager()

    class Meta:
        managed = True
        db_table = 'bloodcamp'
