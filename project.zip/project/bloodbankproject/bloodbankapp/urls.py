from . import views
from django.conf.urls import url

urlpatterns = [
    # admin
    url(r'^index/$', views.index, name="load index page"),
    url(r'^adminloginform/$', views.adminloginform, name="load admin page"),
    url(r'^adminlogin/$', views.adminlogin, name="load admin page"),
    url(r'^adminpasswordform/$', views.adminpasswordform, name="change password "),
    url(r'^adminpassword/$', views.adminpassword, name="change password "),
    url(r'^adminhome/$', views.adminhome, name="load admin page"),
    url(r'^addcampform/$', views.addcampform, name="add camp  form page"),
    url(r'^addcamp/$', views.addcamp, name="load camp page"),
    url(r'^viewbloodcamp/$', views.viewbloodcamp, name="view camps details"),
    url(r'^viewdonors/$', views.viewdonors, name="view donor details"),
    url(r'^addbloodcollectedform/(\d+)/$', views.addbloodcollectedform, name="bloodcollectedform "),
    url(r'^addbloodcollected/$', views.addbloodcollected, name="add blood collection details"),
    url(r'^bloodstockform/$', views.bloodstockform, name="blood stock form "),
    url(r'^bloodstocksave/$', views.bloodstocksave, name="upadated blood stock"),
    url(r'^viewbloodstock/$', views.viewbloodstock, name="view blood stock"),
    url(r'^viewbloodcollected/$', views.viewbloodcollected, name="view blood collection"),
    url(r'^viewrequest/$', views.viewrequest, name="view blood collection"),
    url(r'^viewtransaction/$', views.viewtransaction, name="view transaction list"),
    url(r'^processrequestform/(\d+)/$', views.processrequestform, name="process request list"),
    url(r'^processrequests/(\d+)/$', views.processrequests, name="process request list"),
    url(r'^viewprocessrequest/$', views.viewprocessrequest, name=" view processed request list"),

    # donor
    url(r'^donorregisterform/$', views.donorregisterform, name="load donor register page"),
    url(r'^donorregister/$', views.donorregister, name="load donor register code"),
    url(r'^donorsignin/$', views.donorsignin, name="load donor signin page"),
    url(r'^donorsignform/$', views.donorsignform, name="load donor signin page"),
    url(r'^donorpasswordform/$', views.donorpasswordform, name="change password "),
    url(r'^donorpassword/$', views.donorpassword, name="change password "),
    url(r'^donorhome/$', views.donorhome, name="load donor page "),

    url(r'^bloodrequestform/$', views.bloodrequestform, name="load blood request page "),
    url(r'^bloodrequestcode/$', views.bloodrequestcode, name="load request page "),

    url(r'^generalviewbloodstock/$', views.generalviewbloodstock, name="General view bloodstock page "),
    url(r'^livecamp/$', views.livecamp, name="live blood camp details "),

]
