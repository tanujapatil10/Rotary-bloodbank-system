from django.shortcuts import render
from .models import admin
from .models import donor
from .models import bloodcamp
from .models import blood
from .models import bloodstock
from .models import bloodrequest
from .models import bloodtransaction
from .models import processrequest
import datetime
from django.http import HttpResponse


def index(request):
    return render(request, "bloodbankapp/adminloginform.html")


def adminloginform(request):
    return render(request, "bloodbankapp/adminloginform.html")


def adminlogin(request):
    # get the input
    vemailid = request.POST.get("textemail")
    vpassword = request.POST.get("textpassword")
    request.session["session_emailid"] = vemailid
    request.session["session_password"] = vpassword

    try:
        adminobj = admin.Objects.get(emailid=vemailid, password=vpassword)
        return render(request, 'bloodbankapp/adminhome.html')

    except:
        return HttpResponse("Invaild login")


def donorregisterform(request):
    return render(request, "bloodbankapp/donorregisterform.html")


def donorregister(request):
    vname = request.POST.get("textname")
    vgender = request.POST.get("textgender")
    vbirthdate = request.POST.get("textbirthdate")
    vaddress = request.POST.get("textaddress")
    vcity = request.POST.get("textcity")
    vphone = request.POST.get("textphone")
    vemail = request.POST.get("textemail")
    vpassword = request.POST.get("textpassword")
    voccupation = request.POST.get("textoccupation")
    vbloodgroup = request.POST.get("bloodgroup")
    vmaritalstatus = request.POST.get("textmaritalstatus")
    vlastdonationdate = request.POST.get("textlastdonationdate")

    donorobj = donor(name=vname, gender=vgender, birthdate=vbirthdate,
                     address=vaddress, city=vcity,
                     phone=vphone, email=vemail, password=vpassword, occupation=voccupation,
                     bloodgroup=vbloodgroup,
                     maritalstatus=vmaritalstatus,
                     lastdonationdate=vlastdonationdate)
    donorobj.save()
    return HttpResponse("Registration successfull")


def donorsignform(request):
    return render(request, "bloodbankapp/donorsignform.html")


def donorsignin(request):
    # get the input
    vemail = request.POST.get("textemail")
    vpassword = request.POST.get("textpassword")
    request.session["session_email"] = vemail
    request.session["session_password"] = vpassword

    try:
        donorobj = donor.Objects.get(email=vemail, password=vpassword)
        return render(request, 'bloodbankapp/donorhome.html')

    except:
        return HttpResponse("Invaild login")


def adminpasswordform(request):
    return render(request, 'bloodbankapp/adminpasswordform.html')


def adminpassword(request):
    vemailid = request.session["session_emailid"]
    vpassword = request.session["session_password"]

    # get input from form
    vcurrentpassword = request.POST.get("textcurrentpassword")
    vnewpassword = request.POST.get("textnewpassword")
    vconfirmpassword = request.POST.get("textconfirmpassword")

    if vnewpassword == vconfirmpassword:
        if vpassword == vcurrentpassword:
            adminobj = admin.Objects.get(emailid=vemailid)
            adminobj.password = vnewpassword
            adminobj.save()
            request.session["session_password"] = vnewpassword
            return HttpResponse("change")
        else:
            return HttpResponse("invaild current password")
    else:
        return HttpResponse("new password and confirm password do not match")


def donorpassword(request):
    vemail = request.session["session_email"]
    vpassword = request.session["session_password"]

    # get input from form
    vcurrentpassword = request.POST.get("textcurrentpassword")
    vnewpassword = request.POST.get("textnewpassword")
    vconfirmpassword = request.POST.get("textconfirmpassword")

    if vnewpassword == vconfirmpassword:
        if vpassword == vcurrentpassword:
            donorobj = donor.Objects.get(email=vemail)
            donorobj.password = vnewpassword
            donorobj.save()
            request.session["session_password"] = vnewpassword
            return HttpResponse("change")
        else:
            return HttpResponse("invaild current password")
    else:
        return HttpResponse("new password and confirm password do not match")


def donorpasswordform(request):
    return render(request, 'bloodbankapp/donorpasswordform.html')


def adminhome(request):
    return render(request, "bloodbankapp/adminhome.html")


def donorhome(request):
    return render(request, "bloodbankapp/donorhome.html")


def addcamp(request):
    vname = request.POST.get("textname")
    vaddress = request.POST.get("textaddress")
    vcity = request.POST.get("textcity")
    vphoneno = request.POST.get("textphoneno")
    vcampdate = request.POST.get("textcampdate")

    bloodcampobj = bloodcamp(name=vname, address=vaddress, city=vcity, phoneno=vphoneno, campdate=vcampdate)
    bloodcampobj.save()
    return HttpResponse("Camp is added successfull")


def addcampform(request):
    return render(request, 'bloodbankapp/addcampform.html')


def viewbloodcamp(request):
    bloodcampobj = bloodcamp.Objects.all()
    return render(request, 'bloodbankapp/viewbloodcamp.html', {'bloodcampobj': bloodcampobj})


def viewdonors(request):
    donorobj = donor.Objects.all()
    return render(request, 'bloodbankapp/viewdonors.html', {'donorobj': donorobj})


def addbloodcollectedform(request, x):
    donorobj = donor.Objects.get(donorid=x)
    return render(request, 'bloodbankapp/addbloodcollectedform.html', {'donorobj': donorobj})


def addbloodcollected(request):
    vbagsize = request.POST.get("textbagsize")
    vcollectdate = request.POST.get("textcollectdate")
    vexpirydate = request.POST.get("textexpirydate")
    vstatus = request.POST.get("textstatus")
    vdonorid = request.POST.get("textdonorid")
    vbloodgroup = request.POST.get("textbloodgroup")
    donorobj = donor.Objects.get(donorid=vdonorid)
    bloodobj = blood(donorid=donorobj, bagsize=vbagsize, collectdate=vcollectdate, expirydate=vexpirydate,
                     status=vstatus, bloodgroup=vbloodgroup)
    bloodobj.save()

    # update blood stock
    bloodstockobj = bloodstock.Objects.get(bloodgroup=vbloodgroup, size=vbagsize)
    bloodstockobj.stock = bloodstockobj.stock + 1
    bloodstockavailable = bloodstockobj.stock
    bloodstockobj.save()

    # transaction
    vtransactiondate = datetime.datetime.today()
    vinbag = 1
    voutbag = 0
    vstockbalance = bloodstockavailable
    vtranstype = "In"
    bloodtransactionobj = bloodtransaction(transactiondate=vtransactiondate, inbag=vinbag, outbag=voutbag,
                                           stockbalance=vstockbalance,
                                           transtype=vtranstype, bloodgroup=vbloodgroup)
    bloodtransactionobj.save()
    return HttpResponse("blood collection updated")


def bloodstockform(request):
    return render(request, 'bloodbankapp/bloodstockform.html')


def bloodstocksave(request):
    vbloodgroup = request.POST.get("textbloodgroup")
    vsize = request.POST.get("textsize")
    vstock = request.POST.get("textstock")
    # check if bloodgroup stock is already created then update else create
    exist = bloodstock.Objects.filter(bloodgroup=vbloodgroup, size=vsize).exists()
    if exist:
        return HttpResponse("This blood group stock is already created")
    else:
        bloodstockobj = bloodstock(bloodgroup=vbloodgroup, size=vsize, stock=vstock)
        bloodstockobj.save()
        return HttpResponse("stock saved")


def viewbloodstock(request):
    bloodstockobj = bloodstock.Objects.all().order_by('size').values()
    return render(request, 'bloodbankapp/viewbloodstock.html', {'bloodstockobj': bloodstockobj})


def viewbloodcollected(request):
    bloodobj = blood.Objects.all()
    return render(request, 'bloodbankapp/viewbloodcollected.html', {'bloodobj': bloodobj})


def bloodrequestform(request):
    return render(request, 'bloodbankapp/bloodrequestform.html')


def viewrequest(request):
    bloodrequestobj = bloodrequest.Objects.filter(pending__range=[1,100])
    return render(request, 'bloodbankapp/viewrequest.html', {'bloodrequestobj': bloodrequestobj})


def bloodrequestcode(request):
    vbloodgroup = request.POST.get("textbloodgroup")
    vname = request.POST.get("textname")
    vaddress = request.POST.get("textaddress")
    vcity = request.POST.get("textcity")
    vphoneno = request.POST.get("textphoneno")
    vqty = request.POST.get("textqty")
    vbagsize = request.POST.get("textbagsize")
    vrequeststatus = request.POST.get("textrequeststatus")
    vrequestdate = datetime.datetime.today()
    vpending=vqty
    bloodrequestobj = bloodrequest(bloodgroup=vbloodgroup, name=vname, address=vaddress, city=vcity, phoneno=vphoneno,
                                   qty=vqty, bagsize=vbagsize, requeststatus=vrequeststatus, requestdate=vrequestdate, pending=vpending)
    bloodrequestobj.save()
    return HttpResponse("blood requested")


def viewtransaction(request):
    bloodtransactionobj = bloodtransaction.Objects.all()
    return render(request, 'bloodbankapp/viewtransaction.html', {'bloodtransactionobj': bloodtransactionobj})


def processrequestform(request, requestid):
    request.session["requestid"] = requestid
    bloodrequestobj = bloodrequest.Objects.get(requestid=requestid)
    vbloodgroup = bloodrequestobj.bloodgroup
    bloodobj = blood.Objects.filter(bloodgroup=vbloodgroup, status='Available')
    return render(request, 'bloodbankapp/processrequestform.html', {'bloodobj': bloodobj})


def processrequests(request, bagid):
    requestid = request.session["requestid"]
    vprocessdate = datetime.datetime.today()

    # get bloodgroup based on requestid
    bloodrequestobj = bloodrequest.Objects.get(requestid=requestid)
    bloodgroup = bloodrequestobj.bloodgroup
    bagsize = bloodrequestobj.bagsize
    bloodrequestobj.pending=bloodrequestobj.pending-1
    #bloodrequestobj.save()
    # get blood obj
    bloodobj = blood.Objects.get(bagid=bagid)

    processrequestobj = processrequest(bagid=bloodobj, requestid=bloodrequestobj, processdate=vprocessdate)
    processrequestobj.save()

    # get bloodstock based on bloodgroup and update stock
    bloodstockobj = bloodstock.Objects.get(bloodgroup=bloodgroup, size=bagsize)
    stock = bloodstockobj.stock
    bloodstockobj.stock = stock - 1

    # save to transaction
    vtransactiondate = datetime.datetime.today()
    vinbag = 0
    voutbag = 1
    vstockbalance = stock - 1
    vtranstype = "Out"
    bloodtransactionobj = bloodtransaction(transactiondate=vtransactiondate, inbag=vinbag, outbag=voutbag,
                                           stockbalance=vstockbalance,
                                           transtype=vtranstype, bloodgroup=bloodgroup)
    bloodtransactionobj.save()

    # update status and usedate in blood table
    bloodobj = blood.Objects.get(bagid=bagid)
    bloodobj.status = 'used'
    bloodobj.usedate = datetime.datetime.today()
    bloodobj.save()

    return HttpResponse("processed")


def generalviewbloodstock(request):
    bloodstockobj = bloodstock.Objects.filter().order_by('bloodgroup').values()
    return render(request, 'bloodbankapp/generalviewbloodstock.html', {'bloodstockobj': bloodstockobj})


def viewprocessrequest(request):
    processrequestobj = processrequest.Objects.all()
    return render(request, 'bloodbankapp/viewprocessrequest.html', {'processrequestobj': processrequestobj})

def livecamp(request):
    bloodcampobj = bloodcamp.Objects.all()
    return render(request, 'bloodbankapp/livecamp.html', {'bloodcampobj': bloodcampobj})
